// 通用工具函数
function showToast(message, type = 'info') {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

async function api(url, options = {}) {
  const defaultOptions = {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin'
  };
  if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
    options.body = JSON.stringify(options.body);
  }
  if (options.body instanceof FormData) {
    delete defaultOptions.headers['Content-Type'];
  }
  const res = await fetch(url, { ...defaultOptions, ...options });
  return res.json();
}

async function getCurrentUser() {
  const res = await api('/api/auth/me');
  return res.success ? res.user : null;
}

async function requireLogin() {
  const user = await getCurrentUser();
  if (!user) {
    showToast('请先登录', 'error');
    setTimeout(() => window.location.href = '/login', 1000);
    return null;
  }
  return user;
}

async function requireAdmin() {
  const user = await requireLogin();
  if (!user) return null;
  if (!user.isAdmin) {
    showToast('无权限访问', 'error');
    setTimeout(() => window.location.href = '/', 1000);
    return null;
  }
  return user;
}

async function renderNavbar() {
  const user = await getCurrentUser();
  const navbar = document.getElementById('navbar');
  const drawer = document.getElementById('drawer');
  if (!navbar) return;

  navbar.innerHTML = `
    <div class="logo" onclick="window.location.href='/'">
      <div class="logo-icon">📦</div>
      <span>文件集市</span>
    </div>
    <div class="nav-right">
      ${user ? `<span class="balance-tag">💰 ${user.balance}元</span>` : ''}
      <div class="menu-btn" onclick="toggleDrawer()">☰</div>
    </div>
  `;

  if (drawer) {
    let menuItems = `
      <a href="/" class="drawer-menu-item ${window.location.pathname === '/' ? 'active' : ''}">
        <span class="icon">🏪</span> 文件市场
      </a>
    `;
    if (user) {
      menuItems += `
        <a href="/upload" class="drawer-menu-item"><span class="icon">📤</span> 上传文件</a>
        <a href="/my-files" class="drawer-menu-item"><span class="icon">📂</span> 我的上传</a>
        <a href="/purchases" class="drawer-menu-item"><span class="icon">🛒</span> 我的购买</a>
        <a href="/redeem" class="drawer-menu-item"><span class="icon">🎫</span> 卡密充值</a>
        <a href="/user" class="drawer-menu-item"><span class="icon">👤</span> 个人中心</a>
        ${user.isAdmin ? '<a href="/admin" class="drawer-menu-item"><span class="icon">⚙️</span> 管理后台</a>' : ''}
      `;
    }
    drawer.innerHTML = `
      <div class="drawer-header">
        <div class="drawer-title"><div class="logo-icon" style="width:36px;height:36px;font-size:18px;">📦</div> 文件集市</div>
        <div class="drawer-close" onclick="toggleDrawer()">×</div>
      </div>
      ${user ? `
        <div style="padding:12px 16px;background:var(--bg);border-radius:12px;margin-bottom:16px;">
          <div style="font-size:15px;font-weight:700;">${user.username}</div>
          <div style="font-size:13px;color:var(--text-muted);">${user.email}</div>
          <div style="margin-top:8px;font-size:14px;color:var(--price-text);font-weight:700;">余额：¥${user.balance}</div>
        </div>
      ` : ''}
      ${menuItems}
      <div class="drawer-divider"></div>
      ${user
        ? `<button class="drawer-btn drawer-btn-outline" onclick="logout()">退出登录</button>`
        : `<button class="drawer-btn drawer-btn-outline" onclick="window.location.href='/login'">登录</button>
           <button class="drawer-btn drawer-btn-primary" onclick="window.location.href='/register'">注册</button>`
      }
    `;
  }
}

function toggleDrawer() {
  const drawer = document.getElementById('drawer');
  const overlay = document.getElementById('drawerOverlay');
  if (drawer.classList.contains('active')) {
    drawer.classList.remove('active');
    overlay.classList.remove('active');
  } else {
    drawer.classList.add('active');
    overlay.classList.add('active');
  }
}

async function logout() {
  await api('/api/auth/logout', { method: 'POST' });
  window.location.href = '/';
}

function formatFileSize(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatTime(dateStr) {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  return d.toLocaleString('zh-CN');
}

function startCountdown(btn, seconds = 60) {
  let remaining = seconds;
  btn.disabled = true;
  btn.textContent = `${remaining}s`;
  const timer = setInterval(() => {
    remaining--;
    btn.textContent = `${remaining}s`;
    if (remaining <= 0) {
      clearInterval(timer);
      btn.disabled = false;
      btn.textContent = '获取验证码';
    }
  }, 1000);
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
  document.body.style.overflow = '';
}

document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay') && !e.target.classList.contains('hidden')) {
    e.target.classList.add('hidden');
    document.body.style.overflow = '';
  }
  if (e.target.id === 'drawerOverlay') {
    toggleDrawer();
  }
});
