const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('../database');

const router = express.Router();

// 确保上传目录存在
const uploadDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// 配置multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + '_' + Math.random().toString(36).substr(2, 9) + '.zip';
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/zip' || file.originalname.toLowerCase().endsWith('.zip')) {
      cb(null, true);
    } else {
      cb(new Error('只支持上传zip格式文件'));
    }
  },
  limits: { fileSize: 500 * 1024 * 1024 } // 500MB限制
});

// 中间件：检查是否登录
function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.json({ success: false, message: '请先登录' });
  }
  next();
}

// 获取文件市场列表
router.get('/market', (req, res) => {
  const { search, sort = 'newest', page = 1, pageSize = 12 } = req.query;

  let where = [];
  let params = [];

  if (search) {
    where.push('(f.filename LIKE ? OR f.description LIKE ?)');
    params.push(`%${search}%`, `%${search}%`);
  }

  const whereClause = where.length > 0 ? 'WHERE ' + where.join(' AND ') : '';

  let orderBy = 'f.id DESC';
  if (sort === 'price_asc') orderBy = 'f.price ASC';
  if (sort === 'price_desc') orderBy = 'f.price DESC';
  if (sort === 'sales') orderBy = 'f.sales DESC';

  const offset = (parseInt(page) - 1) * parseInt(pageSize);

  const total = db.prepare(`SELECT COUNT(*) as count FROM files f ${whereClause}`).get(...params).count;

  const files = db.prepare(
    `SELECT f.*, u.username as uploader 
     FROM files f 
     LEFT JOIN users u ON f.user_id = u.id 
     ${whereClause} 
     ORDER BY ${orderBy} 
     LIMIT ? OFFSET ?`
  ).all(...params, parseInt(pageSize), offset);

  // 检查当前用户是否已购买
  const userId = req.session.userId;
  const filesWithStatus = files.map(f => {
    let purchased = false;
    let isOwner = false;
    if (userId) {
      if (f.user_id === userId) isOwner = true;
      const purchase = db.prepare('SELECT id FROM purchases WHERE user_id = ? AND file_id = ?').get(userId, f.id);
      if (purchase) purchased = true;
    }
    return { ...f, purchased, isOwner };
  });

  res.json({ success: true, files: filesWithStatus, total, page: parseInt(page), pageSize: parseInt(pageSize) });
});

// 获取单个文件详情
router.get('/:id', (req, res) => {
  const file = db.prepare(
    `SELECT f.*, u.username as uploader 
     FROM files f 
     LEFT JOIN users u ON f.user_id = u.id 
     WHERE f.id = ?`
  ).get(req.params.id);

  if (!file) {
    return res.json({ success: false, message: '文件不存在' });
  }

  const userId = req.session.userId;
  let purchased = false;
  let isOwner = false;
  if (userId) {
    if (file.user_id === userId) isOwner = true;
    const purchase = db.prepare('SELECT id FROM purchases WHERE user_id = ? AND file_id = ?').get(userId, file.id);
    if (purchase) purchased = true;
  }

  res.json({ success: true, file: { ...file, purchased, isOwner } });
});

// 上传文件
router.post('/upload', requireAuth, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.json({ success: false, message: '请选择文件' });
  }

  const { filename, description, price } = req.body;

  if (!filename || !price) {
    // 删除已上传的文件
    fs.unlinkSync(req.file.path);
    return res.json({ success: false, message: '请填写文件名和价格' });
  }

  const priceNum = parseInt(price);
  if (isNaN(priceNum) || priceNum < 0) {
    fs.unlinkSync(req.file.path);
    return res.json({ success: false, message: '价格无效' });
  }

  const result = db.prepare(
    'INSERT INTO files (user_id, filename, original_name, description, price, file_path, file_size) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(
    req.session.userId,
    filename,
    req.file.originalname,
    description || '',
    priceNum,
    req.file.filename,
    req.file.size
  );

  res.json({ success: true, message: '上传成功', fileId: result.lastInsertRowid });
});

// 购买文件
router.post('/:id/purchase', requireAuth, (req, res) => {
  const fileId = parseInt(req.params.id);
  const userId = req.session.userId;

  const file = db.prepare('SELECT * FROM files WHERE id = ?').get(fileId);
  if (!file) {
    return res.json({ success: false, message: '文件不存在' });
  }

  // 上传者自己不需要购买
  if (file.user_id === userId) {
    return res.json({ success: true, message: '这是您自己的文件，可直接下载', alreadyOwned: true });
  }

  // 检查是否已购买
  const existingPurchase = db.prepare('SELECT id FROM purchases WHERE user_id = ? AND file_id = ?').get(userId, fileId);
  if (existingPurchase) {
    return res.json({ success: true, message: '您已购买此文件，可直接下载', alreadyOwned: true });
  }

  // 检查余额
  const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(userId);
  if (user.balance < file.price) {
    return res.json({ success: false, message: `余额不足，需要${file.price}元，当前余额${user.balance}元` });
  }

  // 事务：扣款 + 记录购买 + 增加销量
  const tx = db.transaction(() => {
    db.prepare('UPDATE users SET balance = balance - ? WHERE id = ?').run(file.price, userId);
    db.prepare('INSERT INTO purchases (user_id, file_id, amount) VALUES (?, ?, ?)').run(userId, fileId, file.price);
    db.prepare('UPDATE files SET sales = sales + 1 WHERE id = ?').run(fileId);
  });

  try {
    tx();
    const updatedUser = db.prepare('SELECT balance FROM users WHERE id = ?').get(userId);
    res.json({ success: true, message: '购买成功', balance: updatedUser.balance });
  } catch (err) {
    console.error('购买失败:', err);
    res.json({ success: false, message: '购买失败，请稍后重试' });
  }
});

// 下载文件
router.get('/:id/download', requireAuth, (req, res) => {
  const fileId = parseInt(req.params.id);
  const userId = req.session.userId;

  const file = db.prepare('SELECT * FROM files WHERE id = ?').get(fileId);
  if (!file) {
    return res.status(404).send('文件不存在');
  }

  // 检查权限：上传者或已购买者
  const isOwner = file.user_id === userId;
  const purchase = db.prepare('SELECT id FROM purchases WHERE user_id = ? AND file_id = ?').get(userId, fileId);

  if (!isOwner && !purchase) {
    return res.status(403).send('请先购买此文件');
  }

  const filePath = path.join(uploadDir, file.file_path);
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('文件已丢失');
  }

  res.download(filePath, file.original_name);
});

// 我的上传
router.get('/my/uploads', requireAuth, (req, res) => {
  const files = db.prepare(
    'SELECT * FROM files WHERE user_id = ? ORDER BY id DESC'
  ).all(req.session.userId);

  // 计算每个文件的收入
  const filesWithIncome = files.map(f => {
    const income = db.prepare('SELECT COALESCE(SUM(amount), 0) as total FROM purchases WHERE file_id = ?').get(f.id).total;
    return { ...f, income };
  });

  const totalIncome = filesWithIncome.reduce((sum, f) => sum + f.income, 0);
  const totalSales = filesWithIncome.reduce((sum, f) => sum + f.sales, 0);

  res.json({ success: true, files: filesWithIncome, totalIncome, totalSales });
});

// 我的购买
router.get('/my/purchases', requireAuth, (req, res) => {
  const purchases = db.prepare(
    `SELECT p.*, f.filename, f.description, f.price, f.file_path, f.original_name, f.file_size, u.username as uploader
     FROM purchases p 
     JOIN files f ON p.file_id = f.id 
     LEFT JOIN users u ON f.user_id = u.id
     WHERE p.user_id = ? 
     ORDER BY p.purchased_at DESC`
  ).all(req.session.userId);

  res.json({ success: true, purchases });
});

// 删除自己上传的文件
router.delete('/:id', requireAuth, (req, res) => {
  const fileId = parseInt(req.params.id);
  const userId = req.session.userId;

  const file = db.prepare('SELECT * FROM files WHERE id = ?').get(fileId);
  if (!file) {
    return res.json({ success: false, message: '文件不存在' });
  }

  if (file.user_id !== userId && !req.session.isAdmin) {
    return res.json({ success: false, message: '无权限删除' });
  }

  // 删除文件记录和物理文件
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM purchases WHERE file_id = ?').run(fileId);
    db.prepare('DELETE FROM files WHERE id = ?').run(fileId);
  });

  try {
    tx();
    const filePath = path.join(uploadDir, file.file_path);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    res.json({ success: true, message: '删除成功' });
  } catch (err) {
    console.error('删除失败:', err);
    res.json({ success: false, message: '删除失败' });
  }
});

module.exports = router;
