const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../database');
const { sendVerificationCode } = require('../mailer');

const router = express.Router();

// 生成6位验证码
function generateCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// 发送验证码
router.post('/send-code', async (req, res) => {
  const { email, purpose } = req.body;

  if (!email || !purpose) {
    return res.json({ success: false, message: '参数不完整' });
  }

  if (!['register', 'reset'].includes(purpose)) {
    return res.json({ success: false, message: '无效的用途' });
  }

  // 注册时检查邮箱是否已存在
  if (purpose === 'register') {
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) {
      return res.json({ success: false, message: '该邮箱已被注册' });
    }
  }

  // 重置密码时检查邮箱是否存在
  if (purpose === 'reset') {
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (!existing) {
      return res.json({ success: false, message: '该邮箱未注册' });
    }
  }

  // 检查60秒内是否已发送
  const recent = db.prepare(
    "SELECT id FROM verification_codes WHERE email = ? AND purpose = ? AND created_at > datetime('now', '-60 seconds')"
  ).get(email, purpose);

  if (recent) {
    return res.json({ success: false, message: '请等待60秒后再发送' });
  }

  const code = generateCode();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

  db.prepare('INSERT INTO verification_codes (email, code, purpose, expires_at) VALUES (?, ?, ?, ?)').run(
    email, code, purpose, expiresAt
  );

  try {
    await sendVerificationCode(email, code, purpose);
    res.json({ success: true, message: '验证码已发送' });
  } catch (err) {
    console.error('邮件发送失败:', err);
    res.json({ success: false, message: '验证码发送失败，请稍后重试' });
  }
});

// 验证验证码
router.post('/verify-code', (req, res) => {
  const { email, code, purpose } = req.body;

  if (!email || !code || !purpose) {
    return res.json({ success: false, message: '参数不完整' });
  }

  const record = db.prepare(
    "SELECT * FROM verification_codes WHERE email = ? AND code = ? AND purpose = ? AND used = 0 AND expires_at > datetime('now') ORDER BY id DESC LIMIT 1"
  ).get(email, code, purpose);

  if (!record) {
    return res.json({ success: false, message: '验证码错误或已过期' });
  }

  res.json({ success: true, message: '验证成功' });
});

// 注册
router.post('/register', (req, res) => {
  const { username, password, email, code } = req.body;

  if (!username || !password || !email || !code) {
    return res.json({ success: false, message: '请填写所有字段' });
  }

  if (password.length !== 6 || !/^\d{6}$/.test(password)) {
    return res.json({ success: false, message: '密码必须是6位数字' });
  }

  // 检查用户名
  const existingUser = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existingUser) {
    return res.json({ success: false, message: '用户名已存在' });
  }

  // 检查邮箱
  const existingEmail = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existingEmail) {
    return res.json({ success: false, message: '邮箱已被注册' });
  }

  // 验证验证码
  const record = db.prepare(
    "SELECT * FROM verification_codes WHERE email = ? AND code = ? AND purpose = 'register' AND used = 0 AND expires_at > datetime('now') ORDER BY id DESC LIMIT 1"
  ).get(email, code);

  if (!record) {
    return res.json({ success: false, message: '验证码错误或已过期' });
  }

  // 标记验证码已使用
  db.prepare('UPDATE verification_codes SET used = 1 WHERE id = ?').run(record.id);

  // 创建用户
  const hashedPassword = bcrypt.hashSync(password, 10);
  const result = db.prepare('INSERT INTO users (username, password, email) VALUES (?, ?, ?)').run(
    username, hashedPassword, email
  );

  // 自动登录
  req.session.userId = result.lastInsertRowid;
  req.session.username = username;
  req.session.isAdmin = false;

  res.json({ success: true, message: '注册成功' });
});

// 登录
router.post('/login', (req, res) => {
  const { account, password } = req.body;

  if (!account || !password) {
    return res.json({ success: false, message: '请填写账号和密码' });
  }

  // 支持用户名或邮箱登录
  const user = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get(account, account);

  if (!user) {
    return res.json({ success: false, message: '账号不存在' });
  }

  if (!bcrypt.compareSync(password, user.password)) {
    return res.json({ success: false, message: '密码错误' });
  }

  req.session.userId = user.id;
  req.session.username = user.username;
  req.session.isAdmin = user.is_admin === 1;

  res.json({
    success: true,
    message: '登录成功',
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      balance: user.balance,
      isAdmin: user.is_admin === 1
    }
  });
});

// 重置密码
router.post('/reset-password', (req, res) => {
  const { email, code, newPassword } = req.body;

  if (!email || !code || !newPassword) {
    return res.json({ success: false, message: '参数不完整' });
  }

  if (newPassword.length !== 6 || !/^\d{6}$/.test(newPassword)) {
    return res.json({ success: false, message: '新密码必须是6位数字' });
  }

  // 验证验证码
  const record = db.prepare(
    "SELECT * FROM verification_codes WHERE email = ? AND code = ? AND purpose = 'reset' AND used = 0 AND expires_at > datetime('now') ORDER BY id DESC LIMIT 1"
  ).get(email, code);

  if (!record) {
    return res.json({ success: false, message: '验证码错误或已过期' });
  }

  // 标记验证码已使用
  db.prepare('UPDATE verification_codes SET used = 1 WHERE id = ?').run(record.id);

  // 更新密码
  const hashedPassword = bcrypt.hashSync(newPassword, 10);
  db.prepare('UPDATE users SET password = ? WHERE email = ?').run(hashedPassword, email);

  res.json({ success: true, message: '密码重置成功' });
});

// 登出
router.post('/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// 获取当前用户信息
router.get('/me', (req, res) => {
  if (!req.session.userId) {
    return res.json({ success: false, message: '未登录' });
  }

  const user = db.prepare('SELECT id, username, email, balance, is_admin FROM users WHERE id = ?').get(req.session.userId);

  if (!user) {
    return res.json({ success: false, message: '用户不存在' });
  }

  res.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      balance: user.balance,
      isAdmin: user.is_admin === 1
    }
  });
});

module.exports = router;
