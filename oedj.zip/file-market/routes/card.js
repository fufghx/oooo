const express = require('express');
const db = require('../database');

const router = express.Router();

// 生成16位卡密（大写字母+数字）
function generateCardCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 16; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// 中间件：检查是否登录
function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.json({ success: false, message: '请先登录' });
  }
  next();
}

// 中间件：检查是否管理员
function requireAdmin(req, res, next) {
  if (!req.session.userId || !req.session.isAdmin) {
    return res.json({ success: false, message: '无权限访问' });
  }
  next();
}

// 用户兑换卡密
router.post('/redeem', requireAuth, (req, res) => {
  const { code } = req.body;

  if (!code) {
    return res.json({ success: false, message: '请输入卡密' });
  }

  const card = db.prepare('SELECT * FROM cards WHERE code = ?').get(code.trim().toUpperCase());

  if (!card) {
    return res.json({ success: false, message: '卡密不存在' });
  }

  if (card.status === 'used') {
    return res.json({ success: false, message: '该卡密已被使用' });
  }

  // 使用事务保证原子性
  const tx = db.transaction(() => {
    // 更新卡密状态
    db.prepare("UPDATE cards SET status = 'used', used_by = ?, used_at = datetime('now') WHERE id = ?").run(
      req.session.userId, card.id
    );
    // 增加用户余额
    db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(card.amount, req.session.userId);
  });

  try {
    tx();
    const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(req.session.userId);
    res.json({ success: true, message: `充值成功，获得${card.amount}元`, balance: user.balance });
  } catch (err) {
    console.error('兑换失败:', err);
    res.json({ success: false, message: '兑换失败，请稍后重试' });
  }
});

// 管理员：批量生成卡密
router.post('/admin/generate', requireAdmin, (req, res) => {
  const { amount, count } = req.body;

  const validAmounts = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

  if (!amount || !count) {
    return res.json({ success: false, message: '参数不完整' });
  }

  const amt = parseInt(amount);
  const cnt = parseInt(count);

  if (!validAmounts.includes(amt)) {
    return res.json({ success: false, message: '无效的面额' });
  }

  if (cnt < 1 || cnt > 500) {
    return res.json({ success: false, message: '生成数量必须在1-500之间' });
  }

  const insertStmt = db.prepare('INSERT INTO cards (code, amount) VALUES (?, ?)');
  const codes = [];

  const tx = db.transaction(() => {
    for (let i = 0; i < cnt; i++) {
      let code;
      let attempts = 0;
      do {
        code = generateCardCode();
        attempts++;
      } while (db.prepare('SELECT id FROM cards WHERE code = ?').get(code) && attempts < 10);

      insertStmt.run(code, amt);
      codes.push(code);
    }
  });

  try {
    tx();
    res.json({ success: true, message: `成功生成${cnt}张${amt}元卡密`, codes });
  } catch (err) {
    console.error('生成卡密失败:', err);
    res.json({ success: false, message: '生成失败，请稍后重试' });
  }
});

// 管理员：获取卡密列表
router.get('/admin/list', requireAdmin, (req, res) => {
  const { status, amount, page = 1, pageSize = 20 } = req.query;

  let where = [];
  let params = [];

  if (status) {
    where.push('status = ?');
    params.push(status);
  }
  if (amount) {
    where.push('amount = ?');
    params.push(parseInt(amount));
  }

  const whereClause = where.length > 0 ? 'WHERE ' + where.join(' AND ') : '';
  const offset = (parseInt(page) - 1) * parseInt(pageSize);

  const total = db.prepare(`SELECT COUNT(*) as count FROM cards ${whereClause}`).get(...params).count;
  const cards = db.prepare(
    `SELECT c.*, u.username as used_by_name FROM cards c 
     LEFT JOIN users u ON c.used_by = u.id 
     ${whereClause} 
     ORDER BY c.id DESC 
     LIMIT ? OFFSET ?`
  ).all(...params, parseInt(pageSize), offset);

  res.json({ success: true, cards, total, page: parseInt(page), pageSize: parseInt(pageSize) });
});

// 管理员：导出卡密（未使用的）
router.get('/admin/export', requireAdmin, (req, res) => {
  const { amount } = req.query;

  let where = ["status = 'unused'"];
  let params = [];

  if (amount) {
    where.push('amount = ?');
    params.push(parseInt(amount));
  }

  const cards = db.prepare(`SELECT code, amount FROM cards WHERE ${where.join(' AND ')} ORDER BY amount, id`).all(...params);

  let text = '';
  cards.forEach(card => {
    text += `${card.code} - ${card.amount}元\n`;
  });

  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename=cards.txt');
  res.send(text);
});

// 管理员：统计信息
router.get('/admin/stats', requireAdmin, (req, res) => {
  const totalCards = db.prepare('SELECT COUNT(*) as count FROM cards').get().count;
  const usedCards = db.prepare("SELECT COUNT(*) as count FROM cards WHERE status = 'used'").get().count;
  const unusedCards = totalCards - usedCards;
  const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  const totalFiles = db.prepare('SELECT COUNT(*) as count FROM files').get().count;
  const totalPurchases = db.prepare('SELECT COUNT(*) as count FROM purchases').get().count;

  // 各面额统计
  const amountStats = db.prepare(
    `SELECT amount, 
            COUNT(*) as total, 
            SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used 
     FROM cards GROUP BY amount ORDER BY amount`
  ).all();

  res.json({
    success: true,
    stats: {
      totalCards,
      usedCards,
      unusedCards,
      totalUsers,
      totalFiles,
      totalPurchases,
      amountStats
    }
  });
});

module.exports = router;
