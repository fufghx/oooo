# 文件交易平台

一个纯本地可运行的文件交易平台，支持用户注册登录、卡密充值、文件上传售卖、购买下载。

## 功能特性

- 用户注册（邮箱验证码）、登录（用户名/邮箱）、密码找回
- 卡密系统：管理员批量生成卡密，用户兑换充值
- 文件交易：上传zip文件、自定义价格、购买下载
- 一次购买永久下载，不重复扣费
- 管理员后台：卡密管理、数据统计
- 登录状态保持30天

## 环境要求

- Node.js >= 16.0.0

## 快速开始

```bash
# 1. 安装依赖
npm install

# 2. 启动服务
npm start
```

启动后访问：http://localhost:3000

## 管理员账号

- 账号：`2359523610@qq.com`（或用户名 `admin`）
- 密码：`114514`

## 邮箱配置

邮箱发送配置在 `mailer.js` 中，当前使用：
- SMTP服务器：smtp.163.com:465
- 发件邮箱：m13518017330@163.com

如需修改，编辑 `mailer.js` 中的 transporter 配置。

## 端口修改

默认端口3000，可通过环境变量修改：
```bash
PORT=8080 npm start
```

## 目录结构

```
├── server.js          # 主入口
├── database.js        # 数据库（SQLite，纯JS实现，无需编译）
├── mailer.js          # 邮件发送
├── package.json
├── routes/
│   ├── auth.js        # 认证（注册/登录/找回密码）
│   ├── card.js        # 卡密（生成/兑换/管理）
│   └── file.js        # 文件（上传/购买/下载）
├── public/            # 前端页面
│   ├── index.html     # 市场首页
│   ├── login.html     # 登录
│   ├── register.html  # 注册
│   ├── forgot.html    # 找回密码
│   ├── user.html      # 用户中心
│   ├── upload.html    # 上传文件
│   ├── purchases.html # 我的购买
│   ├── my-files.html  # 我的上传
│   ├── redeem.html    # 卡密充值
│   ├── admin.html     # 管理员后台
│   ├── css/style.css
│   └── js/app.js
├── data/              # 数据库文件（自动生成）
└── uploads/           # 上传的文件（自动生成）
```

## 卡密面额

支持 10/20/30/40/50/60/70/80/90/100 元，管理员可批量生成1-500张。

## 注意事项

- 上传文件仅支持 .zip 格式，最大500MB
- 密码必须是6位数字
- 验证码5分钟有效，60秒内只能发送一次
- 数据保存在 data/app.db，删除即重置
