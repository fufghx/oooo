const express = require('express');
const session = require('express-session');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session 配置 - 30天有效期
app.use(session({
  secret: 'file-market-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 30 * 24 * 60 * 60 * 1000,
    httpOnly: true
  }
}));

// 静态文件
app.use(express.static(path.join(__dirname, 'public')));

// 路由
app.use('/api/auth', require('./routes/auth'));
app.use('/api/card', require('./routes/card'));
app.use('/api/file', require('./routes/file'));

// 页面路由
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/forgot', (req, res) => res.sendFile(path.join(__dirname, 'public', 'forgot.html')));
app.get('/user', (req, res) => res.sendFile(path.join(__dirname, 'public', 'user.html')));
app.get('/upload', (req, res) => res.sendFile(path.join(__dirname, 'public', 'upload.html')));
app.get('/purchases', (req, res) => res.sendFile(path.join(__dirname, 'public', 'purchases.html')));
app.get('/my-files', (req, res) => res.sendFile(path.join(__dirname, 'public', 'my-files.html')));
app.get('/redeem', (req, res) => res.sendFile(path.join(__dirname, 'public', 'redeem.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

// 错误处理
app.use((err, req, res, next) => {
  console.error(err.stack);
  if (err.message === '只支持上传zip格式文件') {
    return res.json({ success: false, message: err.message });
  }
  res.status(500).json({ success: false, message: '服务器错误' });
});

// 先初始化数据库，再启动服务器
async function start() {
  await db.initDatabase();
  app.listen(PORT, '0.0.0.0', () => {
    console.log('========================================');
    console.log('  文件交易平台已启动');
    console.log(`  访问地址: http://localhost:${PORT}`);
    console.log(`  管理员账号: 2359523610@qq.com`);
    console.log(`  管理员密码: 114514`);
    console.log('========================================');
  });
}

start().catch(err => {
  console.error('启动失败:', err);
  process.exit(1);
});
