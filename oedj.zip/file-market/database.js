const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const dbPath = path.join(__dirname, 'data', 'app.db');

let db = null;
let inTransaction = false;

// 封装 Statement
class Statement {
  constructor(sql) {
    this.stmt = db.prepare(sql);
  }

  _bind(params) {
    if (params.length === 0) return;
    if (params.length === 1 && typeof params[0] === 'object' && !Array.isArray(params[0])) {
      this.stmt.bind(params[0]);
    } else {
      this.stmt.bind(params);
    }
  }

  get(...params) {
    this._bind(params);
    if (this.stmt.step()) {
      const row = this.stmt.getAsObject();
      this.stmt.reset();
      return normalizeRow(row);
    }
    this.stmt.reset();
    return undefined;
  }

  all(...params) {
    this._bind(params);
    const rows = [];
    while (this.stmt.step()) {
      rows.push(normalizeRow(this.stmt.getAsObject()));
    }
    this.stmt.reset();
    return rows;
  }

  run(...params) {
    this._bind(params);
    this.stmt.step();
    this.stmt.reset();
    if (!inTransaction) saveDatabase();
    const result = db.exec('SELECT last_insert_rowid() as id, changes() as changes');
    const id = result[0]?.values[0]?.[0] || 0;
    const changes = result[0]?.values[0]?.[1] || 0;
    return { lastInsertRowid: id, changes };
  }
}

function normalizeRow(row) {
  const normalized = {};
  for (const key in row) {
    let val = row[key];
    if (typeof val === 'string' && /^\d+$/.test(val) && val.length < 15) {
      val = parseInt(val);
    }
    normalized[key] = val;
  }
  return normalized;
}

function saveDatabase() {
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

async function initDatabase() {
  const SQL = await initSqlJs();

  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }

  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    balance INTEGER DEFAULT 0,
    is_admin INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    code TEXT NOT NULL,
    purpose TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS cards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    amount INTEGER NOT NULL,
    status TEXT DEFAULT 'unused',
    used_by INTEGER,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    original_name TEXT NOT NULL,
    description TEXT,
    price INTEGER NOT NULL,
    file_path TEXT NOT NULL,
    file_size INTEGER DEFAULT 0,
    sales INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    file_id INTEGER NOT NULL,
    amount INTEGER NOT NULL,
    purchased_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, file_id)
  )`);

  // 初始化管理员
  const adminEmail = '2359523610@qq.com';
  const adminCheck = db.exec(`SELECT id FROM users WHERE email = '${adminEmail}'`);
  if (!adminCheck[0] || adminCheck[0].values.length === 0) {
    const hashedPassword = bcrypt.hashSync('114514', 10);
    db.run(`INSERT INTO users (username, password, email, is_admin) VALUES ('admin', ?, '${adminEmail}', 1)`, [hashedPassword]);
    console.log('管理员账号已创建');
  }

  saveDatabase();
  console.log('数据库初始化完成');
}

// 封装导出对象
const dbWrapper = {
  prepare(sql) {
    return new Statement(sql);
  },
  exec(sql) {
    return db.exec(sql);
  },
  pragma() {},
  transaction(fn) {
    return function (...args) {
      inTransaction = true;
      db.run('BEGIN');
      try {
        const result = fn.apply(this, args);
        db.run('COMMIT');
        inTransaction = false;
        saveDatabase();
        return result;
      } catch (err) {
        try { db.run('ROLLBACK'); } catch (e) {}
        inTransaction = false;
        throw err;
      }
    };
  }
};

dbWrapper.initDatabase = initDatabase;

module.exports = dbWrapper;
