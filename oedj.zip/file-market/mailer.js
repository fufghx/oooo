const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: 'smtp.163.com',
  port: 465,
  secure: true,
  auth: {
    user: 'm13518017330@163.com',
    pass: 'EUKLAVMjCXXKBeFa'
  }
});

function sendVerificationCode(email, code, purpose) {
  const purposeText = purpose === 'register' ? '注册账号' : '重置密码';
  const mailOptions = {
    from: '"文件交易平台" <m13518017330@163.com>',
    to: email,
    subject: '【文件交易平台】您的验证码',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 10px 10px 0 0; text-align: center;">
          <h2 style="color: #fff; margin: 0;">文件交易平台</h2>
        </div>
        <div style="background: #fff; padding: 30px; border: 1px solid #e0e0e0; border-top: none; border-radius: 0 0 10px 10px;">
          <p style="color: #333; font-size: 16px;">您好，</p>
          <p style="color: #333; font-size: 16px;">您正在进行<strong>${purposeText}</strong>操作，您的验证码为：</p>
          <div style="text-align: center; margin: 30px 0;">
            <span style="display: inline-block; font-size: 36px; font-weight: bold; color: #667eea; letter-spacing: 8px; background: #f0f0ff; padding: 15px 30px; border-radius: 8px;">${code}</span>
          </div>
          <p style="color: #666; font-size: 14px;">验证码有效期为5分钟，请尽快使用。</p>
          <p style="color: #666; font-size: 14px;">如果这不是您本人操作，请忽略此邮件。</p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
          <p style="color: #999; font-size: 12px; text-align: center;">此邮件由系统自动发送，请勿回复</p>
        </div>
      </div>
    `
  };

  return transporter.sendMail(mailOptions);
}

module.exports = { sendVerificationCode };
